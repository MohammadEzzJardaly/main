document.addEventListener("DOMContentLoaded", loadTasks);

function skugen() {
    return Math.floor(10000000 + Math.random() * 90000000).toString();
}

function skuassign() {
    const sku = document.getElementsByClassName("sku");
    for (let i = 0; i < sku.length; i++) {
        sku[i].innerText = `SKU: ${skugen()}`;
    }
}

window.onload = skuassign;

