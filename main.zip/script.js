document.addEventListener("DOMContentLoaded", loadTasks);

const firstImageContainer = document.getElementById("first");
const secondImageContainer = document.getElementById("second");
const thirdImageContainer = document.getElementById("third");

const firstImageDefault = "img/4DFWD 4 RUNNING SHOES/1.avif";
const firstImageHover = "img/4DFWD 4 RUNNING SHOES/2.avif";

const secondImageDefault = "img/Kaptir 3.0 Shoes/1.avif";
const secondImageHover = "img/Kaptir 3.0 Shoes/2.avif";

const thirdImageDefault = "img/Ultraboost 5X Shoes/1.avif";
const thirdImageHover = "img/Ultraboost 5X Shoes/2.avif";

[firstImageContainer, secondImageContainer, thirdImageContainer].forEach(container => {
    container.style.transition = "background-image 0.5s ease";
});

firstImageContainer.addEventListener("mouseenter", () => {
    firstImageContainer.style.backgroundImage = `url('${firstImageHover}')`;
});
firstImageContainer.addEventListener("mouseleave", () => {
    firstImageContainer.style.backgroundImage = `url('${firstImageDefault}')`;
});

secondImageContainer.addEventListener("mouseenter", () => {
    secondImageContainer.style.backgroundImage = `url('${secondImageHover}')`;
});
secondImageContainer.addEventListener("mouseleave", () => {
    secondImageContainer.style.backgroundImage = `url('${secondImageDefault}')`;
});

thirdImageContainer.addEventListener("mouseenter", () => {
    thirdImageContainer.style.backgroundImage = `url('${thirdImageHover}')`;
});
thirdImageContainer.addEventListener("mouseleave", () => {
    thirdImageContainer.style.backgroundImage = `url('${thirdImageDefault}')`;
});


let image = [
    "img/fashion-5515135_1920.jpg",
    "img/pexels-atomlaborblog-1153838.jpg",
    "img/pexels-pixabay-267301.jpg"
];

let text = [
    "Vintage Combat Boots", 
    "Running Shoes", 
    "Urban Luxe Loafers"
];


let currentindex = 0;

let nextbtn = document.getElementById("next");
let prevbtn = document.getElementById("prev");
let imageslider = document.getElementById("image-slider");
let textval = document.getElementById("textval");

function updateimagetxt(){
    imageslider.src = image[currentindex];
    textval.textContent = text[currentindex];
}

prevbtn.addEventListener("click", () => {
    currentindex = (currentindex > 0) ? currentindex - 1 : image.length - 1;
    updateimagetxt();
});

nextbtn.addEventListener("click", () => {
    currentindex = (currentindex < image.length - 1) ? currentindex + 1 : 0;
    updateimagetxt();
});

updateimagetxt();

/*

let hidetable = document.getElementById("table");
let hovertable = document.getElementById("hover-table");

hidetable.style.display = "none";

hovertable.addEventListener(
    "mouseover", () => {
        hidetable.style.display = "table";
});

hovertable.addEventListener("mouseleave", function(){
    hidetable.style.display = "none";
});

hovertable.addEventListener("mouseenter", function() {
    hidetable.style.opacity = "1";
    hidetable.style.visibility = "visible";
});

hovertable.addEventListener("mouseleave", function() {
    hidetable.style.opacity = "0";
    hidetable.style.visibility = "hidden";
});
*/